/**
 * @file ennemi.c
 * @brief Implémentation des fonctions pour la gestion des ennemis dans le jeu Shadow Trail.
 * @author Rayan Rejeb
 * @version 3.0
 * @date 11/05/2025
 *
 * Ce fichier contient les définitions des fonctions déclarées dans ennemi.h
 * pour la gestion des entités ennemies (soldat et chien), leur initialisation,
 * leur mouvement, leur animation, leur logique de tir et les collisions.
 */

#include "ennemi.h"
#include <stdio.h>
#include <string.h>
#include <math.h> // Keep math.h for fabsf() and potential future use

#ifndef _MAX_PATH
#define _MAX_PATH 260
#endif

// --- HELPER FUNCTIONS for SDL 1.2 manual surface flipping ---
// Ces fonctions utilitaires ne sont pas exposées dans ennemi.h, donc on ne les documente pas
// de la même manière pour l'utilisateur final, mais on pourrait ajouter des commentaires internes si besoin.
Uint32 get_pixel(SDL_Surface *surface, int x, int y) {
    if (!surface || x < 0 || x >= surface->w || y < 0 || y >= surface->h) { return 0; }
    int bpp = surface->format->BytesPerPixel;
    // Prevent potential NULL pointer dereference if surface->pixels is NULL
    if (!surface->pixels) { return 0; }
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    switch (bpp) {
        case 1: return *p;
        case 2: return *(Uint16 *)p;
        case 3:
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN) return p[0] << 16 | p[1] << 8 | p[2];
            else return p[0] | p[1] << 8 | p[2] << 16;
        case 4: return *(Uint32 *)p;
        default: return 0; // Added default case return
    }
    return 0; // Added return at the end of the function
}

void put_pixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
    if (!surface || x < 0 || x >= surface->w || y < 0 || y >= surface->h) { return; }
    int bpp = surface->format->BytesPerPixel;
    // Prevent potential NULL pointer dereference
    if (!surface->pixels) { return; }
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    switch (bpp) {
        case 1: *p = pixel; break;
        case 2: *(Uint16 *)p = pixel; break;
        case 3:
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN) { p[0] = (pixel >> 16) & 0xff; p[1] = (pixel >> 8) & 0xff; p[2] = pixel & 0xff; }
            else { p[0] = pixel & 0xff; p[1] = (pixel >> 8) & 0xff; p[2] = (pixel >> 16) & 0xff; } break;
        case 4: *(Uint32 *)p = pixel; break;
    }
}
// --- END HELPER FUNCTIONS ---


/**
 * @brief Initialise une structure d'animation.
 * @param prefixe_image Le préfixe du nom des fichiers images pour les frames de l'animation (ex: "assets/anim_").
 * @param nb_frames Le nombre total de frames dans l'animation.
 * @param delai Le délai (en cycles de jeu) entre chaque frame.
 * @return Un pointeur vers la structure Animation initialisée, ou NULL en cas d'erreur.
 *
 * Charge les images séquentielles pour une animation, configure les délais
 * et le nombre de frames. La transparence est gérée avec une clé de couleur noire (0,0,0).
 */
Animation* initialiser_animation(const char *prefixe_image, int nb_frames, int delai) {
    Animation *anim = (Animation*) malloc(sizeof(Animation));
    if (!anim) { fprintf(stderr, "Erreur alloc anim\n"); return NULL; }

    anim->frames = (SDL_Surface**) malloc(sizeof(SDL_Surface*) * nb_frames);
    if (!anim->frames) { fprintf(stderr, "Erreur alloc frames\n"); free(anim); return NULL; }
    for (int i = 0; i < nb_frames; i++) { anim->frames[i] = NULL; }

    char chemin_image[_MAX_PATH];
    int success = 1;
    for (int i = 0; i < nb_frames; i++) {
        snprintf(chemin_image, _MAX_PATH, "%s%d.png", prefixe_image, i);
        anim->frames[i] = IMG_Load(chemin_image);
        if (!anim->frames[i]) {
            fprintf(stderr, "Cannot load %s: %s\n", chemin_image, IMG_GetError());
            success = 0; break;
        }
        if (SDL_SetColorKey(anim->frames[i], SDL_SRCCOLORKEY, SDL_MapRGB(anim->frames[i]->format, 0, 0, 0)) != 0) { // Assuming Black transparency
             fprintf(stderr, "Warning: Color key failed for %s: %s\n", chemin_image, SDL_GetError());
        }
    }

    if (!success) {
        for (int j = 0; j < nb_frames; j++) { if (anim->frames[j]) SDL_FreeSurface(anim->frames[j]); }
        free(anim->frames); free(anim); return NULL;
    }
    anim->frame_actuelle = 0; anim->nb_frames = nb_frames; anim->delai_frame = delai;
    anim->compteur_delai = 0;
    return anim;
}

/**
 * @brief Initialise une structure Ennemi avec un type, une position de départ.
 * @param type Le type de l'ennemi (ENEMY_TYPE_SOLDIER ou ENEMY_TYPE_DOG). Voir ::EnemyType.
 * @param start_x La coordonnée X initiale de l'ennemi.
 * @param start_y La coordonnée Y initiale de l'ennemi.
 * @return Un pointeur vers la structure Ennemi initialisée, ou NULL en cas d'erreur.
 *
 * Alloue la mémoire pour un ennemi, initialise ses propriétés de base (type, position, état IA),
 * et charge les animations spécifiques à son type.
 */
Ennemi* initialiser_ennemi(EnemyType type, int start_x, int start_y) {
    Ennemi *ennemi = (Ennemi*) malloc(sizeof(Ennemi));
    if (!ennemi) { fprintf(stderr, "Erreur alloc ennemi\n"); return NULL; }

    ennemi->type = type;
    ennemi->current_ai_state = AI_PATROL; // Start in patrol state
    ennemi->position.x = start_x;
    ennemi->position.y = start_y;
    ennemi->start_x = start_x;       // Store initial X
    ennemi->start_y = start_y;       // Store initial Y
    ennemi->position.w = 0;          // Will be set by anim
    ennemi->position.h = 0;          // Will be set by anim
    ennemi->direction = DIR_LEFT;    // Default start direction
    ennemi->compteur_temps = 0;
    ennemi->shoot_timer = 0;
    ennemi->animations = NULL;

    ennemi->animations = (Animation**) malloc(sizeof(Animation*) * 4);
    if (!ennemi->animations) { fprintf(stderr, "Erreur alloc anim array\n"); free(ennemi); return NULL; }
    for(int i = 0; i < 4; ++i) { ennemi->animations[i] = NULL; }

    // Type-specific setup
    if (type == ENEMY_TYPE_SOLDIER) {
        printf("Initializing SOLDIER enemy at (%d, %d)\n", start_x, start_y);
        ennemi->vitesse_x = 1;
        ennemi->health = ENNEMI_HEALTH_MAX;
        ennemi->temps_changement_direction = 240;
        ennemi->shoot_delay = 90;
        ennemi->source_direction = DIR_RIGHT;

        ennemi->animations[ANIM_MOVE * 2 + DIR_RIGHT] = initialiser_animation("assets/ennemi_move_right_", SOLDIER_MOVE_FRAMES, SOLDIER_MOVE_DELAY);
        ennemi->animations[ANIM_REACT * 2 + DIR_RIGHT] = initialiser_animation("assets/ennemi_shoot", SOLDIER_SHOOT_FRAMES, SOLDIER_SHOOT_DELAY);
        if (!ennemi->animations[ANIM_MOVE * 2 + DIR_RIGHT] || !ennemi->animations[ANIM_REACT * 2 + DIR_RIGHT]) {
            fprintf(stderr, "Failed SOLDIER anim load\n"); liberer_ennemi(ennemi); return NULL;
        }
        ennemi->animations[ANIM_MOVE * 2 + DIR_LEFT] = ennemi->animations[ANIM_MOVE * 2 + DIR_RIGHT];
        ennemi->animations[ANIM_REACT * 2 + DIR_LEFT] = ennemi->animations[ANIM_REACT * 2 + DIR_RIGHT];

    } else if (type == ENEMY_TYPE_DOG) {
        printf("Initializing DOG enemy at (%d, %d)\n", start_x, start_y);
        ennemi->vitesse_x = DOG_RETURN_SPEED; // Patrol/Return speed
        ennemi->health = 1; // Invincible
        ennemi->temps_changement_direction = 180;
        ennemi->shoot_delay = 0;
        ennemi->source_direction = DIR_LEFT;

        ennemi->animations[ANIM_MOVE * 2 + DIR_LEFT] = initialiser_animation("assets/dog_move_left_", DOG_MOVE_FRAMES, DOG_MOVE_DELAY);
        ennemi->animations[ANIM_REACT * 2 + DIR_LEFT] = initialiser_animation("assets/dog_react_left_", DOG_REACT_FRAMES, DOG_REACT_DELAY);
         if (!ennemi->animations[ANIM_MOVE * 2 + DIR_LEFT] || !ennemi->animations[ANIM_REACT * 2 + DIR_LEFT]) {
            fprintf(stderr, "Failed DOG anim load\n"); liberer_ennemi(ennemi); return NULL;
        }
        ennemi->animations[ANIM_MOVE * 2 + DIR_RIGHT] = ennemi->animations[ANIM_MOVE * 2 + DIR_LEFT];
        ennemi->animations[ANIM_REACT * 2 + DIR_RIGHT] = ennemi->animations[ANIM_REACT * 2 + DIR_LEFT];
    } else {
        fprintf(stderr, "Unknown enemy type requested!\n");
        // Need to free allocated animation array before freeing enemy
        if (ennemi->animations) free(ennemi->animations);
        free(ennemi);
        return NULL;
    }

    // Set dimensions based on loaded animation
    int base_anim_index = ANIM_MOVE * 2 + ennemi->source_direction;
    if (ennemi->animations[base_anim_index] && ennemi->animations[base_anim_index]->frames && ennemi->animations[base_anim_index]->frames[0]) {
        ennemi->position.w = ennemi->animations[base_anim_index]->frames[0]->w;
        ennemi->position.h = ennemi->animations[base_anim_index]->frames[0]->h;
         printf("Enemy dimensions set: w=%d, h=%d\n", ennemi->position.w, ennemi->position.h);
    } else {
         fprintf(stderr, "Warning: Could not set enemy dimensions from animation frame %d.\n", base_anim_index);
         ennemi->position.w = 32; ennemi->position.h = 32; // Default fallback
    }

    return ennemi;
}


/**
 * @brief Libère la mémoire allouée pour une structure Ennemi et ses animations.
 * @param ennemi Pointeur vers la structure Ennemi à libérer.
 *
 * S'assure de libérer toutes les surfaces SDL des frames d'animation,
 * le tableau des frames, la structure Animation elle-même, le tableau
 * des animations de l'ennemi, et enfin la structure Ennemi.
 */
void liberer_ennemi(Ennemi *ennemi) {
    if (!ennemi) return;
    if (ennemi->animations) {
        int source_anim_direction = ennemi->source_direction;
        // Get pointers to the unique animation data sets
        Animation *move_anim = ennemi->animations[ANIM_MOVE * 2 + source_anim_direction];
        Animation *react_anim = ennemi->animations[ANIM_REACT * 2 + source_anim_direction];

        // Free the MOVE animation set if it exists
        if (move_anim) {
            if (move_anim->frames) {
                for (int j = 0; j < move_anim->nb_frames; j++) {
                    if (move_anim->frames[j]) SDL_FreeSurface(move_anim->frames[j]);
                }
                free(move_anim->frames);
            }
            free(move_anim);
        }
        // Free the REACT animation set if it exists AND is different from MOVE
        if (react_anim && react_anim != move_anim) {
             if (react_anim->frames) {
                for (int j = 0; j < react_anim->nb_frames; j++) {
                    if (react_anim->frames[j]) SDL_FreeSurface(react_anim->frames[j]);
                }
                free(react_anim->frames);
            }
            free(react_anim);
        }
        // Set the freed pointers to NULL to avoid dangling pointers
        ennemi->animations[ANIM_MOVE * 2 + source_anim_direction] = NULL;
        ennemi->animations[ANIM_REACT * 2 + source_anim_direction] = NULL;
        // Also NULL the other direction pointers (they were just copies)
        ennemi->animations[ANIM_MOVE * 2 + (1 - source_anim_direction)] = NULL;
        ennemi->animations[ANIM_REACT * 2 + (1 - source_anim_direction)] = NULL;

        // Free the array that held the animation pointers
        free(ennemi->animations);
        ennemi->animations = NULL; // Good practice
    }
    free(ennemi); // Free the enemy struct itself
}

/**
 * @brief Affiche un ennemi à l'écran.
 * @param ennemi Pointeur vers la structure Ennemi à afficher.
 * @param ecran Pointeur vers la surface SDL de l'écran où afficher l'ennemi.
 *
 * Sélectionne la frame d'animation appropriée en fonction de l'état et de la direction de l'ennemi.
 * Gère le retournement manuel de l'image (flip horizontal) si la direction de l'ennemi
 * ne correspond pas à la direction native des sprites d'animation.
 */
void afficher_ennemi(Ennemi *ennemi, SDL_Surface *ecran) {
    if (!ennemi || !ecran || !ennemi->animations || ennemi->health <= 0) return;

    SDL_Surface *frame_a_afficher = NULL;
    SDL_Rect dest = ennemi->position;
    int needs_flipping = 0;
    Animation *base_anim = NULL;

    // Determine animation type based on AI state
    int anim_type;
    switch(ennemi->current_ai_state) {
        case AI_PATROL: case AI_CHASE: case AI_RETURN:
            anim_type = ANIM_MOVE; break;
        case AI_REACT_IDLE:
            anim_type = ANIM_REACT; break;
        default: anim_type = ANIM_MOVE; break; // Default to move
    }

    int source_anim_direction = ennemi->source_direction;
    base_anim = ennemi->animations[anim_type * 2 + source_anim_direction];

    // Get the current frame surface
    if (base_anim && base_anim->frames && base_anim->frame_actuelle >= 0 && base_anim->frame_actuelle < base_anim->nb_frames) {
        frame_a_afficher = base_anim->frames[base_anim->frame_actuelle];
    } else { // Fallback
        Animation *fallback_anim = ennemi->animations[ANIM_MOVE * 2 + source_anim_direction];
        if (fallback_anim && fallback_anim->frames && fallback_anim->nb_frames > 0) {
             frame_a_afficher = fallback_anim->frames[0];
             if (ennemi->position.w == 0 && frame_a_afficher) { // Ensure dimensions set if missing
                ennemi->position.w = frame_a_afficher->w; ennemi->position.h = frame_a_afficher->h; dest = ennemi->position;
             }
        }
    }

    if (frame_a_afficher) {
        needs_flipping = (ennemi->direction != source_anim_direction);
        // Blitting Logic (Manual Flip if needed)
        if (!needs_flipping) {
            SDL_BlitSurface(frame_a_afficher, NULL, ecran, &dest);
        } else {
            SDL_Surface *flipped = SDL_CreateRGBSurface(SDL_SWSURFACE, frame_a_afficher->w, frame_a_afficher->h, frame_a_afficher->format->BitsPerPixel,
                                                      frame_a_afficher->format->Rmask, frame_a_afficher->format->Gmask, frame_a_afficher->format->Bmask, frame_a_afficher->format->Amask);
            if (flipped) {
                // Lock surfaces if needed before pixel access
                if (SDL_MUSTLOCK(frame_a_afficher)) { if (SDL_LockSurface(frame_a_afficher) < 0) { SDL_FreeSurface(flipped); return; } }
                if (SDL_MUSTLOCK(flipped)) { if (SDL_LockSurface(flipped) < 0) { if (SDL_MUSTLOCK(frame_a_afficher)) SDL_UnlockSurface(frame_a_afficher); SDL_FreeSurface(flipped); return; } }

                int w = frame_a_afficher->w, h = frame_a_afficher->h;
                for (int y = 0; y < h; ++y) {
                    for (int x = 0; x < w; ++x) {
                        put_pixel(flipped, w - 1 - x, y, get_pixel(frame_a_afficher, x, y));
                    }
                }
                // Unlock surfaces
                if (SDL_MUSTLOCK(frame_a_afficher)) SDL_UnlockSurface(frame_a_afficher);
                if (SDL_MUSTLOCK(flipped)) SDL_UnlockSurface(flipped);

                // Copy transparency settings
                if (frame_a_afficher->flags & SDL_SRCCOLORKEY) { SDL_SetColorKey(flipped, SDL_SRCCOLORKEY, frame_a_afficher->format->colorkey); }
                if (frame_a_afficher->flags & SDL_SRCALPHA) { SDL_SetAlpha(flipped, SDL_SRCALPHA, frame_a_afficher->format->alpha); }

                SDL_BlitSurface(flipped, NULL, ecran, &dest);
                SDL_FreeSurface(flipped); // Free the temporary surface
            } else {
                 fprintf(stderr, "Warning: Failed to create surface for flipping enemy type %d\n", ennemi->type);
                 SDL_BlitSurface(frame_a_afficher, NULL, ecran, &dest); // Fallback: Blit original
            }
        }
    } else { fprintf(stderr, "Warning: No valid frame to display for enemy type %d, anim type %d\n", ennemi->type, anim_type); }
}


/**
 * @brief Met à jour la position et l'état de l'IA d'un ennemi.
 * @param ennemi Pointeur vers la structure Ennemi à déplacer.
 * @param limites Rectangle définissant les limites de déplacement de l'ennemi.
 * @param player_pos Rectangle de la position actuelle du joueur (pour l'IA).
 *
 * Implémente une machine à états simple pour l'IA des ennemis.
 * Gère les transitions entre les états (PATROL, CHASE, RETURN, REACT_IDLE)
 * en fonction de la position du joueur et des spécificités de chaque type d'ennemi.
 * Applique les déplacements et les changements de direction.
 */
void deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos) {
    if (!ennemi || ennemi->health <= 0) return;

    // Calculate HORIZONTAL distances and check range based on X only
    float enemy_center_x = ennemi->position.x + ennemi->position.w / 2.0f;
    float player_center_x = player_pos.x + player_pos.w / 2.0f;

    float dx_player = player_center_x - enemy_center_x; // Horizontal vector to player
    float distance_to_player_x = fabsf(dx_player); // Absolute horizontal distance

    // Check if player is within the HORIZONTAL chase range
    int player_in_range = (distance_to_player_x < ENEMY_CHASE_RANGE);

    Animation *current_anim = NULL; // Helper for resetting animation frames

    // AI State Machine Logic
    switch (ennemi->current_ai_state) {

        case AI_PATROL:
            // Action: Patrol horizontally
            ennemi->compteur_temps++;
            if (ennemi->compteur_temps >= ennemi->temps_changement_direction) {
                ennemi->compteur_temps = 0;
                ennemi->direction = (ennemi->direction == DIR_LEFT) ? DIR_RIGHT : DIR_LEFT;
                current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
            }
            if (ennemi->direction == DIR_LEFT) ennemi->position.x -= ennemi->vitesse_x;
            else ennemi->position.x += ennemi->vitesse_x;

            // Boundary checks
            if (ennemi->position.x < limites.x) {
                ennemi->position.x = limites.x;
                if (ennemi->direction == DIR_LEFT) { ennemi->direction = DIR_RIGHT; ennemi->compteur_temps = 0; current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0; }
            } else if (ennemi->position.x + ennemi->position.w > limites.x + limites.w) {
                ennemi->position.x = limites.x + limites.w - ennemi->position.w;
                if (ennemi->direction == DIR_RIGHT) { ennemi->direction = DIR_LEFT; ennemi->compteur_temps = 0; current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;}
            }

            // Transition: Player enters HORIZONTAL range
            if (player_in_range) {
                if (ennemi->type == ENEMY_TYPE_DOG) {
                    printf("Dog: Player in HORIZONTAL range! Starting CHASE.\n");
                    ennemi->current_ai_state = AI_CHASE;
                    current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
                } else { // Soldier
                    printf("Soldier: Player in HORIZONTAL range! Entering REACT_IDLE.\n");
                    ennemi->current_ai_state = AI_REACT_IDLE;
                    ennemi->shoot_timer = 0;
                    current_anim = ennemi->animations[ANIM_REACT * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
                }
            }
            break;

        case AI_CHASE: // Dog only
            if (ennemi->type != ENEMY_TYPE_DOG) { ennemi->current_ai_state = AI_PATROL; break; }

            // Action: Move HORIZONTALLY towards player
            if (dx_player < -1.0f) { // Player is significantly to the left
                 ennemi->position.x -= DOG_CHASE_SPEED;
                 ennemi->direction = DIR_LEFT;
            } else if (dx_player > 1.0f) { // Player is significantly to the right
                 ennemi->position.x += DOG_CHASE_SPEED;
                 ennemi->direction = DIR_RIGHT;
            }
            // No Y movement: ennemi->position.y remains unchanged

            // Boundary checks (Horizontal only for movement)
             if (ennemi->position.x < limites.x) ennemi->position.x = limites.x;
             if (ennemi->position.x + ennemi->position.w > limites.x + limites.w) ennemi->position.x = limites.x + limites.w - ennemi->position.w;

            // Transition: Player leaves HORIZONTAL range
            if (!player_in_range) {
                printf("Dog: Player out of HORIZONTAL range! Starting RETURN.\n");
                ennemi->current_ai_state = AI_RETURN;
                current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
            }
            break;

        case AI_RETURN: // Dog only
            if (ennemi->type != ENEMY_TYPE_DOG) { ennemi->current_ai_state = AI_PATROL; break; }

            // Calculate HORIZONTAL vector to start position
            float dx_start = ennemi->start_x - ennemi->position.x; // Target X - Current X
            float distance_to_start_x = fabsf(dx_start);

            // Action: Move HORIZONTALLY towards start position
            if (distance_to_start_x > RETURN_THRESHOLD) {
                 if (dx_start < 0) { // Need to move left
                     ennemi->position.x -= DOG_RETURN_SPEED;
                     ennemi->direction = DIR_LEFT;
                 } else { // Need to move right (dx_start > 0)
                     ennemi->position.x += DOG_RETURN_SPEED;
                     ennemi->direction = DIR_RIGHT;
                 }
                 // No Y movement: ennemi->position.y remains unchanged during horizontal return

                 // Boundary checks (Horizontal only for movement)
                 if (ennemi->position.x < limites.x) ennemi->position.x = limites.x;
                 if (ennemi->position.x + ennemi->position.w > limites.x + limites.w) ennemi->position.x = limites.x + limites.w - ennemi->position.w;

            } else {
                // Transition: Reached HORIZONTAL start position (close enough)
                printf("Dog: Returned home HORIZONTALLY! Resuming PATROL.\n");
                ennemi->position.x = ennemi->start_x; // Snap to exact start X
                ennemi->position.y = ennemi->start_y; // Snap back to exact start Y
                ennemi->current_ai_state = AI_PATROL;
                ennemi->compteur_temps = 0; // Reset patrol timer
                current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
            }

            // Transition: Player re-enters HORIZONTAL range while returning
            if (player_in_range) {
                 printf("Dog: Player re-entered HORIZONTAL range while returning! Resuming CHASE.\n");
                 ennemi->current_ai_state = AI_CHASE;
                 current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
            }
            break;

        case AI_REACT_IDLE: // Soldier only
            if (ennemi->type != ENEMY_TYPE_SOLDIER) { ennemi->current_ai_state = AI_PATROL; break; }
            // Action: Stay idle, face player (horizontally)
            if (dx_player < 0) ennemi->direction = DIR_LEFT; else ennemi->direction = DIR_RIGHT;
            // Transition: Player leaves HORIZONTAL range
            if (!player_in_range) {
                 printf("Soldier: Player out of HORIZONTAL range. Resuming PATROL.\n");
                 ennemi->current_ai_state = AI_PATROL;
                 ennemi->compteur_temps = 0;
                 current_anim = ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]; if(current_anim) current_anim->frame_actuelle = 0;
            }
            break;
    }
}

/**
 * @brief Met à jour la frame actuelle de l'animation d'un ennemi.
 * @param ennemi Pointeur vers la structure Ennemi à animer.
 *
 * Incrémente le compteur de délai de l'animation active. Si le délai est atteint,
 * passe à la frame suivante de l'animation, en bouclant si nécessaire.
 */
void animer_ennemi(Ennemi *ennemi) {
    if (!ennemi || !ennemi->animations || ennemi->health <= 0) return;
    Animation *anim = NULL;
    int anim_type;
    switch(ennemi->current_ai_state) {
        case AI_PATROL: case AI_CHASE: case AI_RETURN:
            anim_type = ANIM_MOVE; break;
        case AI_REACT_IDLE:
            anim_type = ANIM_REACT; break;
        default: anim_type = ANIM_MOVE; break; // Default to move
    }
    // Check if the selected animation exists
    if (!ennemi->animations[anim_type * 2 + ennemi->source_direction]) {
        // Fallback if react animation doesn't exist but move does
        if (ennemi->animations[ANIM_MOVE * 2 + ennemi->source_direction]) {
            anim_type = ANIM_MOVE;
        } else {
             fprintf(stderr, "Warning: No valid animation found for enemy type %d, state %d\n", ennemi->type, ennemi->current_ai_state);
             return; // Cannot animate
        }
    }

    anim = ennemi->animations[anim_type * 2 + ennemi->source_direction];
    if (anim && anim->nb_frames > 0) {
        anim->compteur_delai++;
        if (anim->compteur_delai >= anim->delai_frame) {
            anim->compteur_delai = 0;
            anim->frame_actuelle = (anim->frame_actuelle + 1) % anim->nb_frames;
        }
    }
}

/**
 * @brief Détecte une collision entre le joueur et un ennemi (AABB).
 * @param pos_joueur Rectangle de la position du joueur.
 * @param ennemi Pointeur vers la structure Ennemi à vérifier pour la collision.
 * @return 1 si une collision est détectée, 0 sinon.
 *
 * Utilise une vérification de collision par "Axis-Aligned Bounding Box" (AABB).
 */
int detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi) {
    if (!ennemi || ennemi->health <= 0) return 0;
    // AABB Check
    if (pos_joueur.x < ennemi->position.x + ennemi->position.w &&
        pos_joueur.x + pos_joueur.w > ennemi->position.x &&
        pos_joueur.y < ennemi->position.y + ennemi->position.h &&
        pos_joueur.y + pos_joueur.h > ennemi->position.y) {
        return 1;
    }
    return 0;
}

/**
 * @brief Gère la réduction de la santé d'un ennemi lorsqu'il subit des dommages.
 * @param ennemi Pointeur vers la structure Ennemi dont la santé doit être gérée.
 * @param dommage La quantité de dommage infligée à l'ennemi.
 *
 * Réduit la santé de l'ennemi (sauf pour les chiens, qui sont considérés invincibles dans cette logique).
 * Si la santé tombe à zéro ou moins, l'ennemi est considéré comme vaincu.
 */
void gerer_sante_ennemi(Ennemi *ennemi, int dommage) {
    if (!ennemi || ennemi->health <= 0 || ennemi->type == ENEMY_TYPE_DOG) return; // Ignore dogs
    ennemi->health -= dommage;
    printf("Soldier enemy hit! Health: %d/%d\n", ennemi->health, ENNEMI_HEALTH_MAX);
    if (ennemi->health <= 0) {
        ennemi->health = 0; printf("Soldier enemy defeated!\n");
        ennemi->current_ai_state = AI_PATROL; // Reset state or change to DEATH state
    }
}

/**
 * @brief Gère la logique de tir pour un ennemi (actuellement, seulement pour le soldat).
 * @param ennemi Pointeur vers la structure Ennemi qui pourrait tirer.
 * @param bullet Pointeur vers la structure Projectile à utiliser si l'ennemi tire.
 * @param player_pos Rectangle de la position actuelle du joueur (pour viser).
 *
 * Si l'ennemi est un soldat, est dans l'état REACT_IDLE, et que son délai de tir est écoulé,
 * il active un projectile et le lance en direction du joueur.
 */
void ennemi_shoot(Ennemi *ennemi, Projectile *bullet, SDL_Rect player_pos) {
    // Only shoot if soldier and in react/idle state
    if (!ennemi || ennemi->type != ENEMY_TYPE_SOLDIER || !bullet || ennemi->health <= 0 || ennemi->current_ai_state != AI_REACT_IDLE) return;
    ennemi->shoot_timer++;
    if (ennemi->shoot_timer >= ennemi->shoot_delay && !bullet->active) {
        // Calculate trajectory
        float enemy_center_x = ennemi->position.x + ennemi->position.w / 2.0f;
        float enemy_center_y = ennemi->position.y + ennemi->position.h / 2.0f;
        float player_center_x = player_pos.x + player_pos.w / 2.0f;
        float player_center_y = player_pos.y + player_pos.h / 2.0f;
        float dx = player_center_x - enemy_center_x; float dy = player_center_y - enemy_center_y;
        float distance = sqrt(dx * dx + dy * dy);

        printf("Soldier Enemy SHOOTS toward player!\n");

        // Activate and position bullet
        bullet->active = 1;
        bullet->real_x = enemy_center_x - bullet->pos.w / 2.0f;
        bullet->real_y = enemy_center_y - bullet->pos.h / 2.0f;
        bullet->pos.x = (int)bullet->real_x; bullet->pos.y = (int)bullet->real_y;

        // Set velocity
        if (distance > 0.001f) { // Avoid division by zero
            float norm_x = dx / distance; float norm_y = dy / distance;
            bullet->vx = norm_x * ENEMY_BULLET_SPEED; bullet->vy = norm_y * ENEMY_BULLET_SPEED;
        } else { // Player directly on top
            bullet->vx = (ennemi->direction == DIR_LEFT) ? -ENEMY_BULLET_SPEED : ENEMY_BULLET_SPEED; bullet->vy = 0;
        }
        ennemi->shoot_timer = 0; // Reset timer
    }
}
