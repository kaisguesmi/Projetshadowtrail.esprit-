var searchData=
[
  ['enemy_5ftype_5fdog_106',['ENEMY_TYPE_DOG',['../ennemi_8h.html#ac3e413a86119db4b031458c7259e268ea8430e3b37212cd7747a4436c5516cfde',1,'ennemi.h']]],
  ['enemy_5ftype_5fsoldier_107',['ENEMY_TYPE_SOLDIER',['../ennemi_8h.html#ac3e413a86119db4b031458c7259e268eac77c7a00f3f1b59a66f7e4ad0783743a',1,'ennemi.h']]]
];
