var searchData=
[
  ['nb_5fframes_85',['nb_frames',['../structAnimation.html#a56df1e313a710037daeed081039a1701',1,'Animation']]]
];
