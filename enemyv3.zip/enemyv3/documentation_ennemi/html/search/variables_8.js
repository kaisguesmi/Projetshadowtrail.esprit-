var searchData=
[
  ['real_5fx_88',['real_x',['../structProjectile.html#a803ce2680d1a5f284c3bcaf59f6ebbb8',1,'Projectile']]],
  ['real_5fy_89',['real_y',['../structProjectile.html#ab3a6e7e7ceeb50a596b179b08e9aca93',1,'Projectile']]]
];
