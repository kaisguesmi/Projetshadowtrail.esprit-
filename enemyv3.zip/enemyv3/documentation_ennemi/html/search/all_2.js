var searchData=
[
  ['delai_5fframe_15',['delai_frame',['../structAnimation.html#a40d5383b00aebd780cbf70f0e6e9c386',1,'Animation']]],
  ['deplacer_5fennemi_16',['deplacer_ennemi',['../ennemi_8c.html#aea55ffc0797c9d9677e2f13d9c00d1ec',1,'deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos):&#160;ennemi.c'],['../ennemi_8h.html#aea55ffc0797c9d9677e2f13d9c00d1ec',1,'deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos):&#160;ennemi.c']]],
  ['detecter_5fcollision_5fjoueur_5fennemi_17',['detecter_collision_joueur_ennemi',['../ennemi_8c.html#ad843197f6a7f96f832e959546f0d419a',1,'detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi):&#160;ennemi.c'],['../ennemi_8h.html#ad843197f6a7f96f832e959546f0d419a',1,'detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi):&#160;ennemi.c']]],
  ['dir_5fleft_18',['DIR_LEFT',['../ennemi_8h.html#a788d3497514ea05602fd974d7bdcdbde',1,'ennemi.h']]],
  ['dir_5fright_19',['DIR_RIGHT',['../ennemi_8h.html#a85ae9767b23edf40871541d23962784b',1,'ennemi.h']]],
  ['direction_20',['direction',['../structEnnemi.html#a5fcc1b018d910c113d7f1cf2771fb900',1,'Ennemi']]],
  ['dog_5fchase_5fspeed_21',['DOG_CHASE_SPEED',['../ennemi_8h.html#a9f94a547466ec9bfaf6cd6a751c13221',1,'ennemi.h']]],
  ['dog_5freturn_5fspeed_22',['DOG_RETURN_SPEED',['../ennemi_8h.html#a93812d93673062b1d61345268eb4a323',1,'ennemi.h']]]
];
