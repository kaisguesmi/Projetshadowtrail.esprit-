var searchData=
[
  ['afficher_5fennemi_65',['afficher_ennemi',['../ennemi_8c.html#aa4156b896b99b6ca72755a730520d328',1,'afficher_ennemi(Ennemi *ennemi, SDL_Surface *ecran):&#160;ennemi.c'],['../ennemi_8h.html#aa4156b896b99b6ca72755a730520d328',1,'afficher_ennemi(Ennemi *ennemi, SDL_Surface *ecran):&#160;ennemi.c']]],
  ['animer_5fennemi_66',['animer_ennemi',['../ennemi_8c.html#a407a50e3a5fd786e13911f713e0dd68e',1,'animer_ennemi(Ennemi *ennemi):&#160;ennemi.c'],['../ennemi_8h.html#a407a50e3a5fd786e13911f713e0dd68e',1,'animer_ennemi(Ennemi *ennemi):&#160;ennemi.c']]]
];
