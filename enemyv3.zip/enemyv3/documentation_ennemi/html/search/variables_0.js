var searchData=
[
  ['active_74',['active',['../structProjectile.html#adf17efc99b04360ba3e64b97971c299b',1,'Projectile']]],
  ['animations_75',['animations',['../structEnnemi.html#ad719fd5b954f53f23d2c6e2b8809dccf',1,'Ennemi']]]
];
