var searchData=
[
  ['gerer_5fsante_5fennemi_35',['gerer_sante_ennemi',['../ennemi_8c.html#a82b3f602379b637484accee076160976',1,'gerer_sante_ennemi(Ennemi *ennemi, int dommage):&#160;ennemi.c'],['../ennemi_8h.html#a82b3f602379b637484accee076160976',1,'gerer_sante_ennemi(Ennemi *ennemi, int dommage):&#160;ennemi.c']]]
];
