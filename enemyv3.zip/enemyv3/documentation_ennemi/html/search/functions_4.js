var searchData=
[
  ['initialiser_5fanimation_71',['initialiser_animation',['../ennemi_8c.html#a405c74bd8d8813f1dc3d5a0d3d2abd96',1,'initialiser_animation(const char *prefixe_image, int nb_frames, int delai):&#160;ennemi.c'],['../ennemi_8h.html#a405c74bd8d8813f1dc3d5a0d3d2abd96',1,'initialiser_animation(const char *prefixe_image, int nb_frames, int delai):&#160;ennemi.c']]],
  ['initialiser_5fennemi_72',['initialiser_ennemi',['../ennemi_8c.html#a4288f3fb632478054f3a8a1415fd3a63',1,'initialiser_ennemi(EnemyType type, int start_x, int start_y):&#160;ennemi.c'],['../ennemi_8h.html#a4288f3fb632478054f3a8a1415fd3a63',1,'initialiser_ennemi(EnemyType type, int start_x, int start_y):&#160;ennemi.c']]]
];
