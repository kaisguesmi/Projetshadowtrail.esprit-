var searchData=
[
  ['deplacer_5fennemi_67',['deplacer_ennemi',['../ennemi_8c.html#aea55ffc0797c9d9677e2f13d9c00d1ec',1,'deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos):&#160;ennemi.c'],['../ennemi_8h.html#aea55ffc0797c9d9677e2f13d9c00d1ec',1,'deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos):&#160;ennemi.c']]],
  ['detecter_5fcollision_5fjoueur_5fennemi_68',['detecter_collision_joueur_ennemi',['../ennemi_8c.html#ad843197f6a7f96f832e959546f0d419a',1,'detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi):&#160;ennemi.c'],['../ennemi_8h.html#ad843197f6a7f96f832e959546f0d419a',1,'detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi):&#160;ennemi.c']]]
];
