var searchData=
[
  ['pos_86',['pos',['../structProjectile.html#a34c10df5b15e2b6299dad913d17045f2',1,'Projectile']]],
  ['position_87',['position',['../structEnnemi.html#aa31d169528ee729764721ae9f258fcd7',1,'Ennemi']]]
];
