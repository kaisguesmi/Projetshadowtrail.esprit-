var searchData=
[
  ['ennemi_5fshoot_69',['ennemi_shoot',['../ennemi_8c.html#a6dff2a8533decaab705beef1b16e69ff',1,'ennemi_shoot(Ennemi *ennemi, Projectile *bullet, SDL_Rect player_pos):&#160;ennemi.c'],['../ennemi_8h.html#a6dff2a8533decaab705beef1b16e69ff',1,'ennemi_shoot(Ennemi *ennemi, Projectile *bullet, SDL_Rect player_pos):&#160;ennemi.c']]]
];
