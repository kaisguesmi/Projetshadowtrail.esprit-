var searchData=
[
  ['delai_5fframe_79',['delai_frame',['../structAnimation.html#a40d5383b00aebd780cbf70f0e6e9c386',1,'Animation']]],
  ['direction_80',['direction',['../structEnnemi.html#a5fcc1b018d910c113d7f1cf2771fb900',1,'Ennemi']]]
];
