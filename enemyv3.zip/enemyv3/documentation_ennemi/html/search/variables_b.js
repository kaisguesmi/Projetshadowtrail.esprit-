var searchData=
[
  ['vitesse_5fx_97',['vitesse_x',['../structEnnemi.html#a4be92a533b8482cb7700c8ae16f04ca0',1,'Ennemi']]],
  ['vx_98',['vx',['../structProjectile.html#a29202389dc05d908a2b16c3b15174546',1,'Projectile']]],
  ['vy_99',['vy',['../structProjectile.html#a2081fe99e23a4605b86c8aab4a5d78b0',1,'Projectile']]]
];
