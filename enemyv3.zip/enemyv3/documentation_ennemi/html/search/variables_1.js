var searchData=
[
  ['compteur_5fdelai_76',['compteur_delai',['../structAnimation.html#a0baaa0b45a957910c824bf3716fcf37e',1,'Animation']]],
  ['compteur_5ftemps_77',['compteur_temps',['../structEnnemi.html#a99e2d5ffebaa7408458ec06bbc56dcef',1,'Ennemi']]],
  ['current_5fai_5fstate_78',['current_ai_state',['../structEnnemi.html#a0eed24c130f27993109e49e8e9b4c9ad',1,'Ennemi']]]
];
