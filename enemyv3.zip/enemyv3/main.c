/**
 * @file main.c
 * @brief Fichier principal de test pour le module ennemi avec soldat et chien.
 * @author Rayan Rejeb
 * @version 3.0
 * @date 11/05/2025
 *
 * Ce programme sert d'exemple d'utilisation et de test pour le module de gestion des ennemis (soldat et chien).
 * Il initialise SDL, gère une boucle de jeu simple avec un joueur,
 * des ennemis de types différents, et des interactions basiques.
 */

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "ennemi.h" // Includes the latest ennemi.h definitions

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define SCREEN_BPP 32

// Asset paths
#define BULLET_IMAGE_FILE "assets/enemy_bullet.png"
#define PLAYER_IMAGE_FILE "assets/joueur.png"
#define HEART_FULL_FILE "assets/heart_full.png"
#define HEART_EMPTY_FILE "assets/heart_empty.png"

// Player Constants
#define PLAYER_MAX_HEALTH 3
#define PLAYER_MOVE_SPEED 5

// Cooldown Constants (milliseconds)
#define DOG_BITE_COOLDOWN 1000
#define SOLDIER_COLLISION_COOLDOWN 1000
#define BULLET_HIT_COOLDOWN 500

// Function to Load Image with Color Key
SDL_Surface* loadImage(const char* filename, Uint8 r, Uint8 g, Uint8 b) {
    SDL_Surface* loadedImage = IMG_Load(filename);
    if (!loadedImage) {
        fprintf(stderr, "Error loading image '%s': %s\n", filename, IMG_GetError());
        return NULL;
    }
    if (SDL_SetColorKey(loadedImage, SDL_SRCCOLORKEY, SDL_MapRGB(loadedImage->format, r, g, b)) != 0) {
        fprintf(stderr, "Warning: Failed to set color key for '%s': %s\n", filename, SDL_GetError());
    }
    return loadedImage;
}


int main(int argc, char *argv[]) {
    (void)argc; (void)argv;

    SDL_Surface *ecran = NULL;
    SDL_Event event;
    int continuer = 1;
    Uint32 background_color;

    // SDL Initialization
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) == -1) { fprintf(stderr, "SDL Init Error: %s\n", SDL_GetError()); return EXIT_FAILURE; }
    if ((IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG) != IMG_INIT_PNG) { fprintf(stderr, "IMG Init Error: %s\n", IMG_GetError()); SDL_Quit(); return EXIT_FAILURE; }

    ecran = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (!ecran) { fprintf(stderr, "Video Mode Error: %s\n", SDL_GetError()); IMG_Quit(); SDL_Quit(); return EXIT_FAILURE; }
    SDL_WM_SetCaption("Ennemi Module - Horizontal Dog AI", NULL); // Updated caption
    srand(time(NULL));
    background_color = SDL_MapRGB(ecran->format, 50, 50, 80);
    SDL_Rect limites_jeu = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};

    // Player Setup
    SDL_Rect pos_joueur = {100, SCREEN_HEIGHT / 2, 0, 0}; // W/H from image
    SDL_Surface *image_joueur = loadImage(PLAYER_IMAGE_FILE, 0, 0, 0);
    if (!image_joueur) { IMG_Quit(); SDL_Quit(); return EXIT_FAILURE; }
    pos_joueur.w = image_joueur->w; pos_joueur.h = image_joueur->h;
    int player_health = PLAYER_MAX_HEALTH;
    Uint32 last_player_hit_time = 0;

    // Hearts Setup
    SDL_Surface *heart_full = loadImage(HEART_FULL_FILE, 0, 0, 0);
    SDL_Surface *heart_empty = loadImage(HEART_EMPTY_FILE, 0, 0, 0);
    if (!heart_full || !heart_empty) { SDL_FreeSurface(image_joueur); IMG_Quit(); SDL_Quit(); return EXIT_FAILURE; }

    // Bullet Setup
    SDL_Surface *image_bullet = loadImage(BULLET_IMAGE_FILE, 0, 0, 0);
    if (!image_bullet) { SDL_FreeSurface(heart_full); SDL_FreeSurface(heart_empty); SDL_FreeSurface(image_joueur); IMG_Quit(); SDL_Quit(); return EXIT_FAILURE; }
    Projectile enemy_bullet;
    enemy_bullet.active = 0; enemy_bullet.vx = 0.0f; enemy_bullet.vy = 0.0f; enemy_bullet.image = image_bullet;
    enemy_bullet.pos.w = image_bullet ? image_bullet->w : 8; enemy_bullet.pos.h = image_bullet ? image_bullet->h : 8;
    enemy_bullet.real_x = 0.0f; enemy_bullet.real_y = 0.0f; enemy_bullet.pos.x = 0; enemy_bullet.pos.y = 0;

    // --- Enemy Setup ---
    int soldier_start_x = 600; int soldier_start_y = 400;
    Ennemi *soldier = initialiser_ennemi(ENEMY_TYPE_SOLDIER, soldier_start_x, soldier_start_y);
    if (!soldier || soldier->position.w == 0 || soldier->position.h == 0) { // Added dimension check
        fprintf(stderr, "Init Soldier Error or dimensions missing\n");
        if(soldier) liberer_ennemi(soldier);
        SDL_FreeSurface(image_bullet); SDL_FreeSurface(heart_full); SDL_FreeSurface(heart_empty); SDL_FreeSurface(image_joueur); IMG_Quit(); SDL_Quit(); return EXIT_FAILURE;
    }

    int dog_start_x = 450;
    // Initialize dog temporarily to get height
    Ennemi *dog = initialiser_ennemi(ENEMY_TYPE_DOG, dog_start_x, 100);
    if (!dog || dog->position.w == 0 || dog->position.h == 0) { // Added dimension check
        fprintf(stderr, "Init Dog Error or dimensions missing\n");
        liberer_ennemi(soldier); // Clean up soldier if dog fails
        if(dog) liberer_ennemi(dog);
        SDL_FreeSurface(image_bullet); SDL_FreeSurface(heart_full); SDL_FreeSurface(heart_empty); SDL_FreeSurface(image_joueur); IMG_Quit(); SDL_Quit(); return EXIT_FAILURE;
     }

    // Calculate final Y and update dog's position and stored start_y
    int dog_final_y = soldier_start_y + soldier->position.h - dog->position.h;
    dog->position.y = dog_final_y;
    dog->start_y = dog_final_y; // *** Update the stored start_y ***
    printf("Aligned Dog Y to: %d and updated start_y\n", dog_final_y);

    // --- Main Loop ---
    Uint32 current_time;
    while (continuer) {
        current_time = SDL_GetTicks();

        // Event Handling
        while (SDL_PollEvent(&event)) {
             switch (event.type) {
                 case SDL_QUIT: continuer = 0; break;
                 case SDL_KEYDOWN:
                     switch (event.key.keysym.sym) {
                         case SDLK_ESCAPE: continuer = 0; break;
                         case SDLK_UP:    pos_joueur.y -= PLAYER_MOVE_SPEED; break;
                         case SDLK_DOWN:  pos_joueur.y += PLAYER_MOVE_SPEED; break;
                         case SDLK_LEFT:  pos_joueur.x -= PLAYER_MOVE_SPEED; break;
                         case SDLK_RIGHT: pos_joueur.x += PLAYER_MOVE_SPEED; break;
                         case SDLK_SPACE: if (soldier) { gerer_sante_ennemi(soldier, 1); } break; // Damage soldier
                         default: break;
                     } break;
             }
        }

        // Player Bounds Check
        if (pos_joueur.x < limites_jeu.x) pos_joueur.x = limites_jeu.x;
        if (pos_joueur.y < limites_jeu.y) pos_joueur.y = limites_jeu.y;
        if (pos_joueur.x + pos_joueur.w > limites_jeu.x + limites_jeu.w) pos_joueur.x = limites_jeu.x + limites_jeu.w - pos_joueur.w;
        if (pos_joueur.y + pos_joueur.h > limites_jeu.y + limites_jeu.h) pos_joueur.y = limites_jeu.y + limites_jeu.h - pos_joueur.h;

        // --- Game Logic Updates ---
        int player_is_immune = (current_time < last_player_hit_time + BULLET_HIT_COOLDOWN ||
                                current_time < last_player_hit_time + DOG_BITE_COOLDOWN ||
                                current_time < last_player_hit_time + SOLDIER_COLLISION_COOLDOWN);

        // Update Soldier
        if (soldier && soldier->health > 0) {
            deplacer_ennemi(soldier, limites_jeu, pos_joueur); // Uses updated AI logic
            animer_ennemi(soldier);
            ennemi_shoot(soldier, &enemy_bullet, pos_joueur);
            if (!player_is_immune && detecter_collision_joueur_ennemi(pos_joueur, soldier)) {
                 player_health--; last_player_hit_time = current_time;
                 printf("OUCH! Player hit by SOLDIER! Health: %d\n", player_health);
                 if (player_health <= 0) { continuer = 0; printf("Game Over!\n"); }
            }
        }

        // Update Dog
        if (dog && dog->health > 0) { // Health > 0 means 'active' for dog
            deplacer_ennemi(dog, limites_jeu, pos_joueur); // Uses updated AI logic
            animer_ennemi(dog);
            if (!player_is_immune && detecter_collision_joueur_ennemi(pos_joueur, dog)) {
                 player_health--; last_player_hit_time = current_time;
                 printf("OUCH! Player bitten by DOG! Health: %d\n", player_health);
                 if (player_health <= 0) { continuer = 0; printf("Game Over!\n"); }
            }
        }

        // Update Bullet
        if (enemy_bullet.active) {
            enemy_bullet.real_x += enemy_bullet.vx; enemy_bullet.real_y += enemy_bullet.vy;
            enemy_bullet.pos.x = (int)enemy_bullet.real_x; enemy_bullet.pos.y = (int)enemy_bullet.real_y;
            // Deactivate if off screen
            if (enemy_bullet.pos.x + enemy_bullet.pos.w < 0 || enemy_bullet.pos.x > SCREEN_WIDTH ||
                enemy_bullet.pos.y + enemy_bullet.pos.h < 0 || enemy_bullet.pos.y > SCREEN_HEIGHT) {
                enemy_bullet.active = 0;
            }
            // Collision with player (AABB check)
            else if (!player_is_immune &&
                     pos_joueur.x < enemy_bullet.pos.x + enemy_bullet.pos.w &&
                     pos_joueur.x + pos_joueur.w > enemy_bullet.pos.x &&
                     pos_joueur.y < enemy_bullet.pos.y + enemy_bullet.pos.h &&
                     pos_joueur.y + pos_joueur.h > enemy_bullet.pos.y)
            {
                enemy_bullet.active = 0; player_health--; last_player_hit_time = current_time;
                printf("PLAYER HIT by bullet! Health: %d\n", player_health);
                if (player_health <= 0) { continuer = 0; printf("Game Over!\n"); }
            }
        }

        // --- Rendering ---
        SDL_FillRect(ecran, NULL, background_color);

        // Draw Player
        if (image_joueur) {
            if (!(player_is_immune && (current_time / 100) % 2 == 0)) { SDL_BlitSurface(image_joueur, NULL, ecran, &pos_joueur); }
        }
        // Draw Enemies
        if (soldier) { afficher_ennemi(soldier, ecran); }
        if (dog) { afficher_ennemi(dog, ecran); }
        // Draw Bullet
        if (enemy_bullet.active && enemy_bullet.image) { SDL_BlitSurface(enemy_bullet.image, NULL, ecran, &enemy_bullet.pos); }

        // Draw Soldier Health Bar
        if (heart_full && heart_empty && soldier && soldier->health > 0) {
            int heart_w = heart_full->w; int heart_h = heart_full->h; int gap = 2;
            int total_hearts_width = ENNEMI_HEALTH_MAX * (heart_w + gap) - gap;
            int health_bar_y = soldier->position.y - heart_h - 5;
            int health_bar_start_x = soldier->position.x + (soldier->position.w / 2) - (total_hearts_width / 2);
            int current_hx = health_bar_start_x;
            for (int i = 0; i < ENNEMI_HEALTH_MAX; i++) {
                SDL_Surface *h_img = (i < soldier->health) ? heart_full : heart_empty;
                SDL_Rect h_pos = {current_hx, health_bar_y, 0, 0}; SDL_BlitSurface(h_img, NULL, ecran, &h_pos);
                current_hx += heart_w + gap;
            }
        }
        // Draw Player Health Bar
        if (heart_full && heart_empty && image_joueur) {
             int hw = heart_full->w; int heart_gap = 2;
             int hx = SCREEN_WIDTH - 10 - (PLAYER_MAX_HEALTH * (hw + heart_gap)); int hy = 10;
             for (int i = 0; i < PLAYER_MAX_HEALTH; i++) {
                 SDL_Surface *h_img = (i < player_health) ? heart_full : heart_empty;
                 SDL_Rect h_pos = {hx, hy, 0, 0}; SDL_BlitSurface(h_img, NULL, ecran, &h_pos);
                 hx += hw + heart_gap;
             }
        }

        SDL_Flip(ecran);
        SDL_Delay(16);
    } // End main loop

    // --- Cleanup ---
    printf("Exiting and cleaning up...\n");
    liberer_ennemi(soldier); liberer_ennemi(dog);
    SDL_FreeSurface(image_bullet); SDL_FreeSurface(image_joueur);
    SDL_FreeSurface(heart_full); SDL_FreeSurface(heart_empty);
    IMG_Quit(); SDL_Quit();
    printf("Cleanup complete.\n");
    if (player_health <= 0) { printf("\n--- You Lost! ---\n"); }
    return EXIT_SUCCESS;
}
