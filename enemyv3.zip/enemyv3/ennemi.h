/**
 * @file ennemi.h
 * @brief En-tête pour la gestion des ennemis (soldat et chien) dans le jeu Shadow Trail.
 * @author Rayan Rejeb
 * @version 3.0
 * @date 11/05/2025
 *
 * Ce fichier contient les déclarations des structures de données (Ennemi, Animation, Projectile),
 * les énumérations (EnemyType, AiState), les constantes et les prototypes des fonctions
 * nécessaires pour gérer les ennemis, leurs animations, leurs déplacements et interactions.
 */
#ifndef ENNEMI_H
#define ENNEMI_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

// --- Health ---
/**
 * @def ENNEMI_HEALTH_MAX
 * @brief Santé maximale pour certains types d'ennemis (ex: soldat).
 */
#define ENNEMI_HEALTH_MAX 3

// --- Animation Types ---
/**
 * @def ANIM_MOVE
 * @brief Identifiant pour l'animation de déplacement.
 */
#define ANIM_MOVE 0
/**
 * @def ANIM_REACT
 * @brief Identifiant pour l'animation de réaction (ex: tir, morsure).
 */
#define ANIM_REACT 1

// --- Directions ---
/**
 * @def DIR_LEFT
 * @brief Identifiant pour la direction gauche.
 */
#define DIR_LEFT 0
/**
 * @def DIR_RIGHT
 * @brief Identifiant pour la direction droite.
 */
#define DIR_RIGHT 1

// --- Enemy Type Enum ---
/**
 * @enum EnemyType
 * @brief Énumération des différents types d'ennemis disponibles.
 *
 * Utilisée pour différencier le comportement, les animations, et les statistiques des ennemis.
 */
typedef enum {
    ENEMY_TYPE_SOLDIER, /*!< Type d'ennemi soldat, capable de tirer. */
    ENEMY_TYPE_DOG      /*!< Type d'ennemi chien, rapide et au contact. */
} EnemyType;

// --- AI State Enum ---
/**
 * @enum AiState
 * @brief Énumération des différents états de l'intelligence artificielle des ennemis.
 *
 * Détermine le comportement actuel de l'ennemi (patrouille, poursuite, etc.).
 */
typedef enum {
    AI_PATROL,      /*!< L'ennemi patrouille horizontalement. */
    AI_CHASE,       /*!< L'ennemi (chien) poursuit le joueur horizontalement. */
    AI_RETURN,      /*!< L'ennemi (chien) retourne à sa position de départ horizontalement. */
    AI_REACT_IDLE   /*!< L'ennemi (soldat) est en mode réaction (ex: vise, tire), ou le chien est en attente. */
} AiState;

// --- AI Constants ---
/**
 * @def ENEMY_CHASE_RANGE
 * @brief Distance horizontale (en pixels) à laquelle un ennemi commence à poursuivre ou réagir au joueur.
 */
#define ENEMY_CHASE_RANGE 300
/**
 * @def ENEMY_BULLET_SPEED
 * @brief Vitesse des projectiles tirés par les ennemis (soldat), en pixels par frame.
 */
#define ENEMY_BULLET_SPEED 4
/**
 * @def DOG_CHASE_SPEED
 * @brief Vitesse horizontale du chien lorsqu'il poursuit le joueur, en pixels par frame.
 */
#define DOG_CHASE_SPEED 3
/**
 * @def DOG_RETURN_SPEED
 * @brief Vitesse horizontale du chien lorsqu'il retourne à sa position de départ, en pixels par frame.
 */
#define DOG_RETURN_SPEED 2
/**
 * @def RETURN_THRESHOLD
 * @brief Seuil de distance (en pixels) pour considérer que le chien est revenu à sa position de départ horizontale.
 */
#define RETURN_THRESHOLD 10

// --- Animation Frame Counts & Delays ---
/** @def SOLDIER_MOVE_FRAMES Nombre de frames pour l'animation de déplacement du soldat. */
#define SOLDIER_MOVE_FRAMES 2
/** @def SOLDIER_SHOOT_FRAMES Nombre de frames pour l'animation de tir du soldat. */
#define SOLDIER_SHOOT_FRAMES 1
/** @def SOLDIER_MOVE_DELAY Délai entre les frames de l'animation de déplacement du soldat. */
#define SOLDIER_MOVE_DELAY 20
/** @def SOLDIER_SHOOT_DELAY Délai entre les frames de l'animation de tir du soldat. */
#define SOLDIER_SHOOT_DELAY 30

/** @def DOG_MOVE_FRAMES Nombre de frames pour l'animation de déplacement du chien. */
#define DOG_MOVE_FRAMES 6
/** @def DOG_REACT_FRAMES Nombre de frames pour l'animation de réaction du chien. */
#define DOG_REACT_FRAMES 1
/** @def DOG_MOVE_DELAY Délai entre les frames de l'animation de déplacement du chien. */
#define DOG_MOVE_DELAY 10
/** @def DOG_REACT_DELAY Délai entre les frames de l'animation de réaction du chien. */
#define DOG_REACT_DELAY 30


// --- Animation Struct ---
/**
 * @struct Animation
 * @brief Structure pour gérer une séquence d'animation.
 *
 * Contient les images (frames), le nombre de frames, la frame actuelle
 * et la logique de temporisation pour l'affichage.
 */
typedef struct {
    SDL_Surface **frames;       /*!< Tableau de pointeurs vers les surfaces SDL (images) de l'animation. */
    int frame_actuelle;         /*!< Index de la frame actuellement affichée. */
    int nb_frames;              /*!< Nombre total de frames dans l'animation. */
    int delai_frame;            /*!< Délai (en cycles de jeu) entre chaque changement de frame. */
    int compteur_delai;         /*!< Compteur interne pour gérer le délai entre les frames. */
} Animation;

// --- Projectile Struct ---
/**
 * @struct Projectile
 * @brief Structure représentant un projectile tiré par un ennemi.
 *
 * Contient sa position (rectangle et coordonnées réelles pour la précision),
 * sa vitesse, son état (actif/inactif) et son image.
 */
typedef struct {
    SDL_Rect pos;               /*!< Rectangle de position et de collision du projectile (coordonnées entières). */
    float real_x;               /*!< Position X réelle (flottante) pour un mouvement plus précis. */
    float real_y;               /*!< Position Y réelle (flottante) pour un mouvement plus précis. */
    float vx;                   /*!< Vitesse horizontale du projectile. */
    float vy;                   /*!< Vitesse verticale du projectile. */
    int active;                 /*!< État du projectile (1 si actif, 0 si inactif). */
    SDL_Surface* image;         /*!< Pointeur vers la surface SDL de l'image du projectile. */
} Projectile;


// --- Ennemi Struct ---
/**
 * @struct Ennemi
 * @brief Structure principale représentant une entité ennemie dans le jeu.
 *
 * Contient toutes les informations nécessaires pour un ennemi : son type, son état IA,
 * sa position, sa vitesse, sa direction, sa santé, ses animations, et des compteurs
 * pour gérer son comportement.
 */
typedef struct {
    EnemyType type;             /*!< Type de l'ennemi (ex: soldat, chien). Voir ::EnemyType. */
    AiState current_ai_state;   /*!< État actuel de l'intelligence artificielle de l'ennemi. Voir ::AiState. */
    SDL_Rect position;          /*!< Rectangle de position et de collision de l'ennemi. */
    int start_x;                /*!< Position X initiale de l'ennemi, utilisée pour le retour. */
    int start_y;                /*!< Position Y initiale de l'ennemi, utilisée pour le retour. */
    int vitesse_x;              /*!< Vitesse de déplacement horizontale de base (pour patrouille/retour). */
    int direction;              /*!< Direction actuelle de l'ennemi (DIR_LEFT ou DIR_RIGHT). Voir ::DIR_LEFT, ::DIR_RIGHT. */
    int source_direction;       /*!< Direction native des sprites d'animation (pour savoir si un flip est nécessaire). */
    int health;                 /*!< Points de vie actuels de l'ennemi. */
    Animation **animations;     /*!< Tableau de pointeurs vers les animations de l'ennemi (déplacement, réaction). */
    int temps_changement_direction; /*!< Durée (en cycles) avant que l'ennemi ne change de direction en mode patrouille. */
    int compteur_temps;         /*!< Compteur interne pour la gestion du temps (ex: changement de direction). */
    int shoot_timer;            /*!< Compteur pour le délai de tir (pour les soldats). */
    int shoot_delay;            /*!< Délai minimum entre deux tirs (pour les soldats). */
} Ennemi;


// --- Function Prototypes ---

/**
 * @brief Initialise une structure d'animation.
 * @param prefixe_image Le préfixe du nom des fichiers images pour les frames de l'animation (ex: "assets/anim_").
 * @param nb_frames Le nombre total de frames dans l'animation.
 * @param delai Le délai (en cycles de jeu) entre chaque frame.
 * @return Un pointeur vers la structure Animation initialisée, ou NULL en cas d'erreur.
 */
Animation* initialiser_animation(const char *prefixe_image, int nb_frames, int delai);

/**
 * @brief Initialise une structure Ennemi avec un type, une position de départ.
 * @param type Le type de l'ennemi (ENEMY_TYPE_SOLDIER ou ENEMY_TYPE_DOG). Voir ::EnemyType.
 * @param start_x La coordonnée X initiale de l'ennemi.
 * @param start_y La coordonnée Y initiale de l'ennemi.
 * @return Un pointeur vers la structure Ennemi initialisée, ou NULL en cas d'erreur.
 */
Ennemi* initialiser_ennemi(EnemyType type, int start_x, int start_y);

/**
 * @brief Libère la mémoire allouée pour une structure Ennemi et ses animations.
 * @param ennemi Pointeur vers la structure Ennemi à libérer.
 */
void liberer_ennemi(Ennemi *ennemi);

/**
 * @brief Affiche un ennemi à l'écran.
 * @param ennemi Pointeur vers la structure Ennemi à afficher.
 * @param ecran Pointeur vers la surface SDL de l'écran où afficher l'ennemi.
 */
void afficher_ennemi(Ennemi *ennemi, SDL_Surface *ecran);

/**
 * @brief Met à jour la position et l'état de l'IA d'un ennemi.
 * @param ennemi Pointeur vers la structure Ennemi à déplacer.
 * @param limites Rectangle définissant les limites de déplacement de l'ennemi.
 * @param player_pos Rectangle de la position actuelle du joueur (pour l'IA).
 */
void deplacer_ennemi(Ennemi *ennemi, SDL_Rect limites, SDL_Rect player_pos);

/**
 * @brief Met à jour la frame actuelle de l'animation d'un ennemi.
 * @param ennemi Pointeur vers la structure Ennemi à animer.
 */
void animer_ennemi(Ennemi *ennemi);

/**
 * @brief Détecte une collision entre le joueur et un ennemi (AABB).
 * @param pos_joueur Rectangle de la position du joueur.
 * @param ennemi Pointeur vers la structure Ennemi à vérifier pour la collision.
 * @return 1 si une collision est détectée, 0 sinon.
 */
int detecter_collision_joueur_ennemi(SDL_Rect pos_joueur, Ennemi *ennemi);

/**
 * @brief Gère la réduction de la santé d'un ennemi lorsqu'il subit des dommages.
 * @param ennemi Pointeur vers la structure Ennemi dont la santé doit être gérée.
 * @param dommage La quantité de dommage infligée à l'ennemi.
 */
void gerer_sante_ennemi(Ennemi *ennemi, int dommage);

/**
 * @brief Gère la logique de tir pour un ennemi (actuellement, seulement pour le soldat).
 * @param ennemi Pointeur vers la structure Ennemi qui pourrait tirer.
 * @param bullet Pointeur vers la structure Projectile à utiliser si l'ennemi tire.
 * @param player_pos Rectangle de la position actuelle du joueur (pour viser).
 */
void ennemi_shoot(Ennemi *ennemi, Projectile *bullet, SDL_Rect player_pos);

#endif // ENNEMI_H
